package ProjetoBaseDois.utils;

public class Utils {
}
